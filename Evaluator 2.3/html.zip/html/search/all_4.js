var searchData=
[
  ['generar_5fproblema_5fsesion_51',['generar_problema_sesion',['../_curso_8cc.html#ad71a63d7c1a87afc7745e70e7e149486',1,'Curso.cc']]]
];
