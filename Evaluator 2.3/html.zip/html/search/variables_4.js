var searchData=
[
  ['map_5fproblema_5fsesion_192',['map_problema_sesion',['../class_curso.html#a2e3bc3b80549ff5e1668c6dbd28ded93',1,'Curso']]],
  ['modificado_193',['modificado',['../class_cjt___problemas.html#a06ac8b18be12b2b6c2c5a80b020c020b',1,'Cjt_Problemas']]]
];
