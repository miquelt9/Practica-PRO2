var searchData=
[
  ['id_52',['id',['../class_curso.html#a8b03115ec376127bdbe684598d1c265d',1,'Curso::id()'],['../class_problema.html#aaf6f4828ac60bca54966e37b1105d266',1,'Problema::id()'],['../class_sesion.html#a6019a4209e2e26b602274bf474f77de7',1,'Sesion::id()'],['../class_usuario.html#abb6f98493464fddc7a7f82203d08fc1d',1,'Usuario::id()']]],
  ['inscribir_5fcurso_53',['inscribir_curso',['../class_cjt___usuarios.html#a135fe58b62527924163ca8be459fbdd8',1,'Cjt_Usuarios::inscribir_curso()'],['../class_usuario.html#a67dfa5de9cb6d779051373002b853b18',1,'Usuario::inscribir_curso()']]],
  ['insertar_5fproblemas_54',['insertar_problemas',['../_sesion_8cc.html#a3abc0a278d8540821964960de212e60f',1,'Sesion.cc']]]
];
