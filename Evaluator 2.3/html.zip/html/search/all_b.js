var searchData=
[
  ['reducir_5fregistrados_79',['reducir_registrados',['../class_cjt___cursos.html#aef7aaca3e15096060a2976f56bc99f97',1,'Cjt_Cursos::reducir_registrados()'],['../class_curso.html#af7f5586d39255ee840fcd9a7591029b4',1,'Curso::reducir_registrados()']]],
  ['resueltos_80',['resueltos',['../class_usuario.html#a20c4c6ec0664e9cc7c6e5def349aed38',1,'Usuario']]]
];
