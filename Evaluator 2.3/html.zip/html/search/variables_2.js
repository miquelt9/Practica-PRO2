var searchData=
[
  ['enviables_188',['enviables',['../class_usuario.html#a6efe4e36066e07fbff684032342f584a',1,'Usuario']]],
  ['envios_5fcorrectos_189',['envios_correctos',['../class_problema.html#a086bcfe12a44df13cb5312471fbfa467',1,'Problema']]],
  ['envios_5ftotales_190',['envios_totales',['../class_problema.html#abaee308b1ebcc3c1b3620fffc33a4196',1,'Problema']]]
];
