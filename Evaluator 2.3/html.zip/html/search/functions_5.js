var searchData=
[
  ['inscribir_5fcurso_160',['inscribir_curso',['../class_cjt___usuarios.html#a135fe58b62527924163ca8be459fbdd8',1,'Cjt_Usuarios::inscribir_curso()'],['../class_usuario.html#a67dfa5de9cb6d779051373002b853b18',1,'Usuario::inscribir_curso()']]],
  ['insertar_5fproblemas_161',['insertar_problemas',['../_sesion_8cc.html#a3abc0a278d8540821964960de212e60f',1,'Sesion.cc']]]
];
