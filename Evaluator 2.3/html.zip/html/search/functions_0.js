var searchData=
[
  ['actualizar_5fmap_124',['actualizar_map',['../_cjt___problemas_8cc.html#a2c3703355d42e52b31ad5c39a3403482',1,'Cjt_Problemas.cc']]],
  ['agregar_5fcurso_125',['agregar_curso',['../class_cjt___cursos.html#abd4f0131166d7ece85dc4efd4be4c118',1,'Cjt_Cursos']]],
  ['agregar_5fenviables_126',['agregar_enviables',['../class_usuario.html#ae1923be1deaebd9f74fd6ac69a1a2163',1,'Usuario']]],
  ['agregar_5fhijos_127',['agregar_hijos',['../class_cjt___sesiones.html#a36cb237f98d4616b148ce54344c1c932',1,'Cjt_Sesiones']]],
  ['agregar_5fproblema_128',['agregar_problema',['../class_cjt___problemas.html#acd1367fbd3b8b5946a5d10bcca14cab9',1,'Cjt_Problemas']]],
  ['agregar_5fsesion_129',['agregar_sesion',['../class_cjt___sesiones.html#ad5edb6c952c2484b7e1ea8f05c2f1ea8',1,'Cjt_Sesiones']]],
  ['alta_5fusuario_130',['alta_usuario',['../class_cjt___usuarios.html#af63d9a48e93611cf079ca0eb084f4f83',1,'Cjt_Usuarios::alta_usuario(const string &amp;u)'],['../class_cjt___usuarios.html#a0f7736ac81834398f04e8633a6448bd1',1,'Cjt_Usuarios::alta_usuario(const Usuario &amp;u)']]],
  ['aumentar_5fcompletados_131',['aumentar_completados',['../class_cjt___cursos.html#afa1dda69d23325706fb27e408cd0515b',1,'Cjt_Cursos::aumentar_completados()'],['../class_curso.html#a36a844ead618cd6cfb1933f927064c8a',1,'Curso::aumentar_completados()']]],
  ['aumentar_5fenvios_5fcorrectos_132',['aumentar_envios_correctos',['../class_cjt___problemas.html#a8965b4dc3fc4bcaeab42fc78301c2907',1,'Cjt_Problemas::aumentar_envios_correctos()'],['../class_problema.html#a3cdf07604168f75e96cb519b848c085e',1,'Problema::aumentar_envios_correctos()']]],
  ['aumentar_5fenvios_5ftotales_133',['aumentar_envios_totales',['../class_cjt___problemas.html#a902bb8fdf30159f56d727cf242fe8858',1,'Cjt_Problemas::aumentar_envios_totales()'],['../class_problema.html#a9712d7d1ec6f2377e5d23027f5f5c785',1,'Problema::aumentar_envios_totales()']]],
  ['aumentar_5fregistrados_134',['aumentar_registrados',['../class_cjt___cursos.html#a8e18c0c89db4aa12c9e03913f7883161',1,'Cjt_Cursos::aumentar_registrados()'],['../class_curso.html#a9b00f287c60643df889ce46626d6dd2f',1,'Curso::aumentar_registrados()']]]
];
