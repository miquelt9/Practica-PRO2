var searchData=
[
  ['usuario_184',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#a1a3e8e06c59b3df1fffdc7d3882548fd',1,'Usuario::Usuario(const Usuario &amp;u)'],['../class_usuario.html#a2136570641cbea865aeb377719f78894',1,'Usuario::Usuario(const string &amp;n)']]]
];
