var searchData=
[
  ['ordenados_194',['ordenados',['../class_cjt___problemas.html#a8991c6d61d31020c2de054da947eb10f',1,'Cjt_Problemas']]]
];
