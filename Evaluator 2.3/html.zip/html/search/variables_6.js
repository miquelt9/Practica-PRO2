var searchData=
[
  ['problemas_195',['problemas',['../class_cjt___problemas.html#a8f528a53dfe97e0b313dd3172f779565',1,'Cjt_Problemas::problemas()'],['../class_sesion.html#a14705faf40ec81a9a9b15a40eeabfbfe',1,'Sesion::problemas()']]]
];
