var searchData=
[
  ['numero_5fcursos_165',['numero_cursos',['../class_cjt___cursos.html#a82a0fa62976636ce52804aa36203652e',1,'Cjt_Cursos']]],
  ['numero_5finscritos_166',['numero_inscritos',['../class_curso.html#a4c0cc8df75164e560e5071ccc2780d9d',1,'Curso']]],
  ['numero_5fproblemas_167',['numero_problemas',['../class_cjt___problemas.html#af049fb6ccc84abbd8c23cae4217f9677',1,'Cjt_Problemas::numero_problemas()'],['../class_cjt___sesiones.html#ac7ee34e15620a08b3cd1c113d9c40180',1,'Cjt_Sesiones::numero_problemas()'],['../class_sesion.html#accbe4daeb470dbd8a38caddf5b4c2578',1,'Sesion::numero_problemas()']]],
  ['numero_5fsesiones_168',['numero_sesiones',['../class_cjt___sesiones.html#a2be0fd6934608b192083d319d7f0cccd',1,'Cjt_Sesiones']]],
  ['numero_5fusuarios_169',['numero_usuarios',['../class_cjt___cursos.html#acf2d18049604421835952bdecba6d56d',1,'Cjt_Cursos::numero_usuarios()'],['../class_cjt___usuarios.html#af9060b6ad1f883a2b00297b827bfbb96',1,'Cjt_Usuarios::numero_usuarios()']]]
];
