var searchData=
[
  ['resueltos_196',['resueltos',['../class_usuario.html#a20c4c6ec0664e9cc7c6e5def349aed38',1,'Usuario']]]
];
