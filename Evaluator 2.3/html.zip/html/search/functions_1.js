var searchData=
[
  ['baja_5fusuario_135',['baja_usuario',['../class_cjt___usuarios.html#adcd3fbded5d8f4c21456e9b9f8200a07',1,'Cjt_Usuarios']]]
];
