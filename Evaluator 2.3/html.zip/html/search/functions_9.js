var searchData=
[
  ['primer_5fproblema_170',['primer_problema',['../class_cjt___sesiones.html#a1c9bbb0dd671fcc3d3428c52c1b7e5aa',1,'Cjt_Sesiones']]],
  ['primeros_5fproblemas_171',['primeros_problemas',['../class_cjt___sesiones.html#a4bccd7ce9fef24b71b9ae43a3436f18b',1,'Cjt_Sesiones']]],
  ['problema_172',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#aef0d8bbee80a8060fe80b60b149c2878',1,'Problema::Problema(const Problema &amp;p)'],['../class_problema.html#a19ecd7b09d3618d2f0ec38e225d7e774',1,'Problema::Problema(const string &amp;n)']]],
  ['problemas_5fenviables_173',['problemas_enviables',['../class_cjt___usuarios.html#a187c3b228ba69f3647148056d254c639',1,'Cjt_Usuarios::problemas_enviables()'],['../class_usuario.html#a79c8b5d178c8cfe7604210dc38d41fa1',1,'Usuario::problemas_enviables()']]],
  ['problemas_5fintentados_174',['problemas_intentados',['../class_usuario.html#a9e979d448a585c52d0a7cd583679a467',1,'Usuario']]],
  ['problemas_5frepetidos_175',['problemas_repetidos',['../class_curso.html#a0b13cd5bf8af953a257a49bf73ce3d12',1,'Curso']]],
  ['problemas_5fresueltos_176',['problemas_resueltos',['../class_cjt___usuarios.html#a9056eb6a6de6b476fd608d6ef717be54',1,'Cjt_Usuarios::problemas_resueltos()'],['../class_usuario.html#a11b719ee95e8089a4f34c172c81f2a5b',1,'Usuario::problemas_resueltos()']]],
  ['problemas_5fsesion_177',['problemas_sesion',['../class_cjt___sesiones.html#ad63e62249b588ecc25cfb14bc67ae6bc',1,'Cjt_Sesiones::problemas_sesion()'],['../class_sesion.html#ae51bb8cbf244abff4b3c97c8662fc734',1,'Sesion::problemas_sesion()']]]
];
